# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pig']

package_data = \
{'': ['*'], 'pig': ['config/*']}

install_requires = \
['git',
 'google-cloud-storage>=2.5.0,<3.0.0',
 'install>=1.3.5,<2.0.0',
 'pip>=22.2.2,<23.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'typer>=0.6.1,<0.7.0']

setup_kwargs = {
    'name': 'pig',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jim Cassidy',
    'author_email': 'jim@ion8.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
